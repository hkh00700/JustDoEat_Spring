package com.hanul.jstdoeat.Service;

import org.springframework.ui.Model;

public interface FoodService {
	public String excute(Model model);
}
