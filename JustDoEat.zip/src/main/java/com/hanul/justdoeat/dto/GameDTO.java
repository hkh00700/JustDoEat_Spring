package com.hanul.justdoeat.dto;

public class GameDTO {

}
