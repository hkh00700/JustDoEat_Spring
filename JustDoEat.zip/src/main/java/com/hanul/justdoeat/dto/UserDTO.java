package com.hanul.justdoeat.dto;

public class UserDTO {

}
