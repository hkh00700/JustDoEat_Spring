package com.hanul.justdoeat.command;

public class GameCommand {

}
