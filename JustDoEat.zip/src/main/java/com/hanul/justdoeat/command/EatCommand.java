package com.hanul.justdoeat.command;

import org.springframework.ui.Model;

public interface EatCommand {
	public void execute(Model model);
}
