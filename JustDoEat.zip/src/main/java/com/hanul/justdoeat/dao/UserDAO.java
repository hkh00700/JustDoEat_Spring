package com.hanul.justdoeat.dao;

public class UserDAO {

}
