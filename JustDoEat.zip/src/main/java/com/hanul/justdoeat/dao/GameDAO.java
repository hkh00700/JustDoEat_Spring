package com.hanul.justdoeat.dao;

public class GameDAO {

}
