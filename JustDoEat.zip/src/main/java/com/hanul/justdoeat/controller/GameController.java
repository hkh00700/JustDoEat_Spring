package com.hanul.justdoeat.controller;

import org.springframework.stereotype.Controller;

@Controller
public class GameController {
	
	

}
